
package blood_management_system_final;

public class Main {
    
    public static void main(String[] args) {
        LoginForm login = new LoginForm();
        login.setVisible(true);
        
    }
    
}
