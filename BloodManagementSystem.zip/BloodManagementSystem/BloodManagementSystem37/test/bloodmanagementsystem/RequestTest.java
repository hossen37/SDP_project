package bloodmanagementsystem;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import static org.junit.Assert.*;
import org.junit.Test;
public class RequestTest {
    
    
    
    
    @Test
    public void testSaveToFile() {
        Donor donor = new Donor();
        
       
        String testData = "sohan,sohan@gmail.com,123456789,O+,khaja Hall";
        
        
        donor.saveToFile(testData);
        
        
        try (BufferedReader reader = new BufferedReader(new FileReader("data.txt"))) {
            String line;
            boolean foundTestData = false;
            while ((line = reader.readLine()) != null) {
                if (line.equals(testData)) {
                    foundTestData = true;
                    break;
                }
            }
            assertTrue(foundTestData);
            
        } catch (IOException e) {
            fail("Exception thrown while reading file: " + e.getMessage());
        }
    }
    
    
    
     @Test
    public void testLoadDataFromFile() {
        Donor donor = new Donor();
        
        
        String expectedData = "sohan,sohan@gmail.com,123456789,O+,khaja Hall";
        
       
        donor.loadDataFromFile();
        
        
        String actualData = donor.jtable.getValueAt(0, 0).toString() + "," +
                             donor.jtable.getValueAt(0, 1).toString() + "," +
                             donor.jtable.getValueAt(0, 2).toString() + "," +
                             donor.jtable.getValueAt(0, 3).toString() + "," +
                             donor.jtable.getValueAt(0, 4).toString();
        
        
        assertEquals(expectedData, actualData);
    }
    
    @Test
    public void testUIComponentsVisibility() {
        // instance of the Donor class
        Donor donor = new Donor();
        
        
        assertTrue("Name text field is visible", donor.tfName.isVisible());
        assertTrue("Email text field is visible", donor.tfEmail.isVisible());
    }
    
    
    
}
