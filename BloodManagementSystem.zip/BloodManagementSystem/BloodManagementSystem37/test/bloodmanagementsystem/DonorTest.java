package bloodmanagementsystem;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import static org.junit.Assert.*;
import org.junit.Test;

public class DonorTest {
    
    
    
    @Test
    public void testAddButtonActionPerformed() {
        Donor donor = new Donor();
        
        
        donor.tfName.setText("Mursalin");
        donor.tfEmail.setText("mursalin@gmail.com");
        donor.tfPhone.setText("123456789");
        donor.tfBlood.setText("B+");
        donor.tfAddress.setText("khaba Hall");
        
        
        donor.AddButton.doClick();
        
        
        int lastRowIndex = donor.jtable.getRowCount() - 1;
        String actualData = donor.jtable.getValueAt(lastRowIndex, 0).toString() + "," +
                            donor.jtable.getValueAt(lastRowIndex, 1).toString() + "," +
                            donor.jtable.getValueAt(lastRowIndex, 2).toString() + "," +
                            donor.jtable.getValueAt(lastRowIndex, 3).toString() + "," +
                            donor.jtable.getValueAt(lastRowIndex, 4).toString();
        
       String expectedData = "Mursalin,mursalin@gmail.com,123456789,B+,khaba Hall";
        
        assertEquals(expectedData, actualData);
    }

    
    
    

    @Test
    public void testClearButton() {
        Donor donor = new Donor();
        donor.tfName.setText("sohan");
        donor.tfEmail.setText("sohan@gmail.com");
        donor.tfPhone.setText("123456789");
        donor.tfBlood.setText("O+");
        donor.tfAddress.setText("khaja Hall");

        
           donor.AddButton.doClick();

        assertEquals("", donor.tfName.getText());
        assertEquals("", donor.tfEmail.getText());
    }


    
    @Test
    public void testLoadDataFromFile() {
        Donor donor = new Donor();
        
        
        String expectedData = "sohan,sohan@gmail.com,123456789,O+,khaja Hall";
        
     
        donor.loadDataFromFile();
        
       
        String actualData = donor.jtable.getValueAt(0, 0).toString() + "," +
                             donor.jtable.getValueAt(0, 1).toString() + "," +
                             donor.jtable.getValueAt(0, 2).toString() + "," +
                             donor.jtable.getValueAt(0, 3).toString() + "," +
                             donor.jtable.getValueAt(0, 4).toString();
        
        assertEquals(expectedData, actualData);
    }
    
    
    @Test
    public void testSaveToFile() {
        Donor donor = new Donor();
        
        
        String testData = "sohan,sohan@gmail.com,123456789,O+,khaja Hall";
        
       
        donor.saveToFile(testData);
        
        
        try (BufferedReader reader = new BufferedReader(new FileReader("data.txt"))) {
            String line;
            boolean foundTestData = false;
            while ((line = reader.readLine()) != null) {
                if (line.equals(testData)) {
                    foundTestData = true;
                    break;
                }
            }
            
            assertTrue(foundTestData);
            
        } catch (IOException e) {
            fail("Exception thrown while reading file: " + e.getMessage());
        }
    }
    
    
    
     @Test
    public void testUIComponentsNotNull() {
        
        Donor donor = new Donor();
                
        assertNotNull("Name text field is not null", donor.tfName);
        assertNotNull("Email text field is not null", donor.tfEmail);
        
        
    }

    @Test
    public void testUIComponentsVisibility() {
        
        Donor donor = new Donor();
        
        assertTrue("Name text field is visible", donor.tfName.isVisible());
        assertTrue("Email text field is visible", donor.tfEmail.isVisible());
    }
    
}
