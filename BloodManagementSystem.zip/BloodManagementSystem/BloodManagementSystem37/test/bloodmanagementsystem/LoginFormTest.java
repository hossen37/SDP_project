package bloodmanagementsystem;
import javax.swing.JOptionPane;
import org.junit.Test;
import static org.junit.Assert.*;

public class LoginFormTest {
    
    public LoginFormTest() {
    }

    /**
     * Test of login with valid credentials.
     */
    @Test
    public void testLoginWithValidCredentials() {
        // Create an instance of the LoginForm class
        LoginForm loginForm = new LoginForm();

        // Set the username and password
        loginForm.UserName_Jtext.setText("sohan");
        loginForm.Password_Jtext.setText("1234");

        // Trigger the login button action performed
        loginForm.Login_Button.doClick();

        // Assert that the Home window is visible after successful login
        assertTrue("Home window is visible after successful login", loginForm.isVisible());
    
    }
//    @Test
//    public void testLoginWithValidCredentials() {
//        System.out.println("loginWithValidCredentials");
//        LoginForm loginForm = new LoginForm();
//        loginForm.UserName_Jtext.setText("sohan");
//        loginForm.Password_Jtext.setText("1234");
//
//        // You need to check if the home window is visible after successful login
//        assertTrue("Home window should be visible after successful login", true);
//    }
//    
    /**
     * Test of login with invalid credentials.
     */
//  @Test
//    public void testLoginWithInvalidCredentials() {
//        System.out.println("loginWithInvalidCredentials");
//        LoginForm loginForm = new LoginForm();
//        loginForm.UserName_Jtext.setText("Invalid");
//        loginForm.Password_Jtext.setText("1234");
//       // loginForm.Login_ButtonActionPerformed(null);
//        // You need to check if an error message dialog is displayed after unsuccessful login
//        assertFalse("Error message dialog should be displayed after unsuccessful login", false);
//    }
    
        @Test
    public void testLoginWithInvalidCredentials() {
        // Create an instance of the LoginForm class
        LoginForm loginForm = new LoginForm();

        // Set invalid username and password
        loginForm.UserName_Jtext.setText("invalidname");
        loginForm.Password_Jtext.setText("invalidPass");

        // Trigger the login button action performed
        loginForm.Login_Button.doClick();

        // Assert that a login failure message is displayed
       // assertTrue("Login failure message is displayed", JOptionPane.getRootFrame().isActive());
        assertTrue("Login form is still visible", loginForm.isVisible());
    }

}
