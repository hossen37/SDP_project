
package bloodmanagementsystem;
import javax.swing.table.DefaultTableModel;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

public class SearchTest {
    
    
   @Test
    public void testSearchFilter() {
        
        
        DefaultTableModel model = (DefaultTableModel) searchFrame.jtable.getModel();
        String searchText = "sohan";  
        searchFrame.search.setText(searchText);
        searchFrame.searchKeyReleased(null);  

        boolean containsFilteredValue = false;
        for (int i = 0; i < model.getRowCount(); i++) {
            for (int j = 0; j < model.getColumnCount(); j++) {
                if (model.getValueAt(i, j).toString().contains(searchText)) {
                    containsFilteredValue = true;
                    break;
                }
            }
        }
        
        
        assertTrue("Search filter should show rows containing the search text", containsFilteredValue);
    }  
    
    
    
    
   @Test
    public void testLoadDataFromFile() {
        Donor donor = new Donor();
        
       
        String expectedData = "sohan,sohan@gmail.com,123456789,O+,khaja Hall";
        
      
        donor.loadDataFromFile();
        
        
        String actualData = donor.jtable.getValueAt(0, 0).toString() + "," +
                             donor.jtable.getValueAt(0, 1).toString() + "," +
                             donor.jtable.getValueAt(0, 2).toString() + "," +
                             donor.jtable.getValueAt(0, 3).toString() + "," +
                             donor.jtable.getValueAt(0, 4).toString();
        
    assertEquals(expectedData, actualData);
    }
    
     private Search searchFrame;

    @Before
    public void setUp() {
      
        searchFrame = new Search();
        searchFrame.setVisible(true); 
    }

    @After
    public void tearDown() {
        searchFrame.dispose(); 
    }

    @Test
    public void testComponentsNotNull() {
        // Check if all components are properly initialize
        
        assertNotNull(searchFrame.jtable);
        
        assertNotNull(searchFrame.search);
    }

     @Test
    public void testTableInitialPopulation() {
        
        // Assuming your file data.txt has a known number of rows for testing
        DefaultTableModel model = (DefaultTableModel) searchFrame.jtable.getModel();
        
        int rowCount = model.getRowCount();
        
        assertTrue("Table should be initially populated from file", rowCount > 0);
    }
    

}
