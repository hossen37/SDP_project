
package bloodmanagementsystem;

public class Main {
    
    public static void main(String[] args) {
        LoginForm login = new LoginForm();
        login.setVisible(true);
        
    }
    
}
