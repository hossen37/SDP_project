/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bloodmanagementsystem;

/**
 *
 * @author USER
 */
public class calculator {
    int sum;
    public calculator(int a, int b)
    {
        sum = a + b;
    }
    public int getsum()
    {
        return sum;
    }
    
}
